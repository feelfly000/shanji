window.SHANJI_ROUTES = [
  {
    "id": "FZ001",
    "name": "福道精华段",
    "region": "鼓楼区",
    "type": "城市森林步道",
    "difficulty": "轻松",
    "distance": 5.8,
    "time": 2,
    "ascent": 180,
    "transit": "公交/打车",
    "transitFriendly": true,
    "themes": [
      "城市森林",
      "栈道",
      "亲子"
    ],
    "audience": [
      "新手",
      "亲子",
      "游客"
    ],
    "score": 98,
    "highlight": "不用出城就能走的标志性城市森林步道，适合第一次体验。",
    "summary": "适合用作网站的新手样板路线：路况清楚、出口较多、观景点密集，用户容易理解路线价值。",
    "warning": "周末人流较大，雨天栈道可能湿滑，恐高人群需谨慎。",
    "verify": "入口、开放时间、不同出口交通",
    "x": "38%",
    "y": "42%",
    "color": "#7fb27a",
    "status": "资料已整理",
    "gpx": {
      "status": "无轨迹",
      "downloadable": false,
      "file": "",
      "note": "V0.1内测阶段暂不开放下载，待实地复核和轨迹清洗后更新。"
    },
    "updatedAt": "2026-06-18"
  },
  {
    "id": "FZ002",
    "name": "福山-福道-冶山历史风貌区",
    "region": "鼓楼区",
    "type": "城市山地+人文",
    "difficulty": "轻松",
    "distance": 6.2,
    "time": 2.5,
    "ascent": 160,
    "transit": "公交/地铁周边",
    "transitFriendly": true,
    "themes": [
      "城市森林",
      "历史人文"
    ],
    "audience": [
      "新手",
      "游客",
      "摄影"
    ],
    "score": 89,
    "highlight": "把福道和城市历史节点串起来，适合做文化轻徒步专题。",
    "summary": "路线更偏城市漫步和轻量登高，适合外地游客或周末低强度活动。",
    "warning": "需要确认实际串联动线，避免城市道路段过长影响体验。",
    "verify": "实际步行串联方式和耗时",
    "x": "39%",
    "y": "39%",
    "color": "#9dbf77",
    "status": "候选待复核",
    "gpx": {
      "status": "无轨迹",
      "downloadable": false,
      "file": "",
      "note": "V0.1内测阶段暂不开放下载，待实地复核和轨迹清洗后更新。"
    },
    "updatedAt": "2026-06-18"
  },
  {
    "id": "FZ003",
    "name": "鼓山登山道-涌泉寺",
    "region": "晋安区",
    "type": "古道登山",
    "difficulty": "中等",
    "distance": 7.5,
    "time": 3.5,
    "ascent": 520,
    "transit": "地铁+步行/打车",
    "transitFriendly": true,
    "themes": [
      "古道",
      "寺庙",
      "城市观景"
    ],
    "audience": [
      "新手进阶",
      "半日",
      "摄影"
    ],
    "score": 96,
    "highlight": "福州经典登高古道，交通方便，但台阶强度不低。",
    "summary": "适合作为市区入门进阶路线。它的优势是识别度高、交通便利、文化景观密集。",
    "warning": "雨后石阶湿滑，节假日人多，夏季闷热。",
    "verify": "台阶强度、节假日人流、返程方式",
    "x": "55%",
    "y": "42%",
    "color": "#6ea36f",
    "status": "候选待复核",
    "gpx": {
      "status": "无轨迹",
      "downloadable": false,
      "file": "",
      "note": "V0.1内测阶段暂不开放下载，待实地复核和轨迹清洗后更新。"
    },
    "updatedAt": "2026-06-18"
  },
  {
    "id": "FZ004",
    "name": "鼓山-十八景-喝水岩-白云顶",
    "region": "晋安区",
    "type": "古道+观景",
    "difficulty": "较难",
    "distance": 11.5,
    "time": 5.5,
    "ascent": 780,
    "transit": "地铁+公交/打车",
    "transitFriendly": true,
    "themes": [
      "古道",
      "观景",
      "训练"
    ],
    "audience": [
      "进阶",
      "摄影"
    ],
    "score": 91,
    "highlight": "比普通鼓山线更完整，适合有一定体力的人做半日到一日训练。",
    "summary": "这条线可以展示路线详情页的分段说明、风险提示和下撤信息，是原型里的进阶样板。",
    "warning": "爬升明显，部分路段需确认开放和路况，不建议新手独行。",
    "verify": "分段距离、爬升、白云顶开放状态",
    "x": "58%",
    "y": "36%",
    "color": "#8b7749",
    "status": "候选待复核",
    "gpx": {
      "status": "无轨迹",
      "downloadable": false,
      "file": "",
      "note": "V0.1内测阶段暂不开放下载，待实地复核和轨迹清洗后更新。"
    },
    "updatedAt": "2026-06-18"
  },
  {
    "id": "FZ005",
    "name": "鼓山白云洞/凤池白云洞线",
    "region": "晋安区",
    "type": "登山观景",
    "difficulty": "较难",
    "distance": 9.2,
    "time": 4.5,
    "ascent": 720,
    "transit": "公交/打车",
    "transitFriendly": false,
    "themes": [
      "观景",
      "寺庙",
      "训练"
    ],
    "audience": [
      "进阶",
      "摄影"
    ],
    "score": 80,
    "highlight": "观景和登山属性强，适合做进阶路线内容。",
    "summary": "路线需要更严格核验，适合展示网站对高强度路线的安全边界表达。",
    "warning": "台阶多、体力要求较高，雨后和夜间不建议尝试。",
    "verify": "台阶数量、路况、是否适合下山",
    "x": "57%",
    "y": "34%",
    "color": "#8d5f45",
    "status": "候选待复核",
    "gpx": {
      "status": "无轨迹",
      "downloadable": false,
      "file": "",
      "note": "V0.1内测阶段暂不开放下载，待实地复核和轨迹清洗后更新。"
    },
    "updatedAt": "2026-06-18"
  },
  {
    "id": "FZ006",
    "name": "鼓山-鼓岭线路",
    "region": "晋安区",
    "type": "古道+避暑",
    "difficulty": "较难",
    "distance": 13.5,
    "time": 6,
    "ascent": 900,
    "transit": "公交/接驳",
    "transitFriendly": false,
    "themes": [
      "古道",
      "避暑",
      "历史人文"
    ],
    "audience": [
      "进阶",
      "游客"
    ],
    "score": 88,
    "highlight": "官方十大名山线路之一，兼具古道、人文和夏季避暑价值。",
    "summary": "适合做鼓山鼓岭专题的核心路线，但正式发布前要细化起终点和交通。",
    "warning": "耗时较长，返程接驳需要提前计划。",
    "verify": "具体起终点、接驳交通、耗时",
    "x": "60%",
    "y": "31%",
    "color": "#4d8b6f",
    "status": "候选待复核",
    "gpx": {
      "status": "无轨迹",
      "downloadable": false,
      "file": "",
      "note": "V0.1内测阶段暂不开放下载，待实地复核和轨迹清洗后更新。"
    },
    "updatedAt": "2026-06-18"
  },
  {
    "id": "FZ007",
    "name": "鼓岭柳杉王公园-鼓岭栈道",
    "region": "晋安区",
    "type": "避暑轻徒步",
    "difficulty": "轻松",
    "distance": 5.6,
    "time": 2.2,
    "ascent": 180,
    "transit": "公交/自驾",
    "transitFriendly": true,
    "themes": [
      "森林",
      "避暑",
      "亲子"
    ],
    "audience": [
      "新手",
      "亲子",
      "游客"
    ],
    "score": 92,
    "highlight": "夏季避暑、亲子和游客都容易理解的轻徒步选择。",
    "summary": "适合作为夏季专题入口，强度不高但交通和停车信息要写清楚。",
    "warning": "山上天气变化快，节假日停车和接驳需提前确认。",
    "verify": "景区交通、开放时间、停车",
    "x": "62%",
    "y": "28%",
    "color": "#5f9e78",
    "status": "候选待复核",
    "gpx": {
      "status": "无轨迹",
      "downloadable": false,
      "file": "",
      "note": "V0.1内测阶段暂不开放下载，待实地复核和轨迹清洗后更新。"
    },
    "updatedAt": "2026-06-18"
  },
  {
    "id": "FZ008",
    "name": "五虎山-五灵岩寺折返",
    "region": "闽侯县",
    "type": "郊野登山",
    "difficulty": "中等",
    "distance": 8.4,
    "time": 4,
    "ascent": 560,
    "transit": "自驾/打车",
    "transitFriendly": false,
    "themes": [
      "名山",
      "寺庙",
      "训练"
    ],
    "audience": [
      "新手进阶",
      "进阶"
    ],
    "score": 84,
    "highlight": "山体辨识度高，适合作为闽侯方向的登山样板。",
    "summary": "适合有一定体力的周末登山用户，正式发布时要确认停车和折返点。",
    "warning": "部分路段暴晒，雨后土路和石阶需注意防滑。",
    "verify": "起点停车、步道状态、折返节点",
    "x": "30%",
    "y": "66%",
    "color": "#94734c",
    "status": "候选待复核",
    "gpx": {
      "status": "无轨迹",
      "downloadable": false,
      "file": "",
      "note": "V0.1内测阶段暂不开放下载，待实地复核和轨迹清洗后更新。"
    },
    "updatedAt": "2026-06-18"
  },
  {
    "id": "FZ009",
    "name": "五虎山-龙祥岛-旗山湖",
    "region": "闽侯县",
    "type": "山岛湖串联",
    "difficulty": "中等",
    "distance": 12,
    "time": 5.5,
    "ascent": 480,
    "transit": "自驾/接驳",
    "transitFriendly": false,
    "themes": [
      "名山",
      "湖景",
      "亲水"
    ],
    "audience": [
      "进阶",
      "游客"
    ],
    "score": 78,
    "highlight": "官方十大名山线路之一，适合做闽侯山岛湖专题。",
    "summary": "更像目的地串联路线，网站里需要区分徒步段和游览段。",
    "warning": "点位串联可能依赖车辆接驳，不应直接宣传为纯徒步线。",
    "verify": "串联是否适合步行、交通接驳",
    "x": "28%",
    "y": "70%",
    "color": "#608ba4",
    "status": "候选待复核",
    "gpx": {
      "status": "无轨迹",
      "downloadable": false,
      "file": "",
      "note": "V0.1内测阶段暂不开放下载，待实地复核和轨迹清洗后更新。"
    },
    "updatedAt": "2026-06-18"
  },
  {
    "id": "FZ010",
    "name": "旗山-万佛寺-博思软件线路",
    "region": "闽侯县/高新区",
    "type": "名山+古刹",
    "difficulty": "中等",
    "distance": 10.8,
    "time": 5,
    "ascent": 620,
    "transit": "自驾/公交部分可达",
    "transitFriendly": false,
    "themes": [
      "名山",
      "寺庙",
      "森林"
    ],
    "audience": [
      "新手进阶",
      "进阶"
    ],
    "score": 82,
    "highlight": "名山、古刹和产业园区形成多元路线主题。",
    "summary": "适合在原型里测试复杂路线的标签和专题归类。",
    "warning": "需要确认实际徒步段比例，避免城市道路段过多。",
    "verify": "实际徒步段和城市道路占比",
    "x": "24%",
    "y": "58%",
    "color": "#7f9d68",
    "status": "候选待复核",
    "gpx": {
      "status": "无轨迹",
      "downloadable": false,
      "file": "",
      "note": "V0.1内测阶段暂不开放下载，待实地复核和轨迹清洗后更新。"
    },
    "updatedAt": "2026-06-18"
  }
];
