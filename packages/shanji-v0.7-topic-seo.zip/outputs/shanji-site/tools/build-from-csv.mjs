import fs from "node:fs/promises";

const root = new URL("../", import.meta.url);
const dataDir = new URL("data/", root);

function parseCsv(text) {
  const rows = [];
  let row = [];
  let cell = "";
  let quoted = false;
  for (let i = 0; i < text.length; i += 1) {
    const ch = text[i];
    const next = text[i + 1];
    if (quoted) {
      if (ch === '"' && next === '"') {
        cell += '"';
        i += 1;
      } else if (ch === '"') {
        quoted = false;
      } else {
        cell += ch;
      }
      continue;
    }
    if (ch === '"') {
      quoted = true;
    } else if (ch === ",") {
      row.push(cell);
      cell = "";
    } else if (ch === "\n") {
      row.push(cell);
      if (row.some(Boolean)) rows.push(row);
      row = [];
      cell = "";
    } else if (ch !== "\r") {
      cell += ch;
    }
  }
  if (cell || row.length) {
    row.push(cell);
    rows.push(row);
  }
  const [headers, ...body] = rows;
  return body.map(values => Object.fromEntries(headers.map((header, index) => [header, values[index] ?? ""])));
}

function splitList(value) {
  return value ? value.split("|").map(item => item.trim()).filter(Boolean) : [];
}

function bool(value) {
  return value === "true" || value === "是";
}

function number(value) {
  return Number(value);
}

function osmUrl(route) {
  return `https://www.openstreetmap.org/?mlat=${route.location.lat}&mlon=${route.location.lng}#map=14/${route.location.lat}/${route.location.lng}`;
}

function pageShell(title, body, prefix = "..") {
  return `<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>${title}</title>
  <link rel="stylesheet" href="${prefix}/assets/styles.css?v=0.7">
</head>
<body>
  <main class="detail-page">
    <a class="back-link" href="${prefix}/index.html">返回山迹首页</a>
${body}
  </main>
</body>
</html>
`;
}

const routeRows = parseCsv(await fs.readFile(new URL("routes-v0.5.csv", dataDir), "utf8"));
const activityRows = parseCsv(await fs.readFile(new URL("activities-v0.5.csv", dataDir), "utf8"));
const gpxRows = parseCsv(await fs.readFile(new URL("gpx-v0.5.csv", dataDir), "utf8"));
const gpxById = new Map(gpxRows.map(row => [row.id, row]));

const routes = routeRows.map((row, index) => {
  const gpx = gpxById.get(row.id) || {};
  return {
    id: row.id,
    name: row.name,
    region: row.region,
    type: row.type,
    difficulty: row.difficulty,
    distance: number(row.distance),
    time: number(row.time),
    ascent: number(row.ascent),
    transit: row.transit,
    transitFriendly: bool(row.transitFriendly),
    themes: splitList(row.themes),
    audience: splitList(row.audience),
    score: number(row.score),
    highlight: row.highlight,
    summary: row.summary,
    warning: row.warning,
    verify: row.verify,
    x: `${30 + index * 5}%`,
    y: `${35 + (index % 5) * 8}%`,
    color: row.color,
    status: row.status,
    updatedAt: row.updatedAt,
    location: {
      lat: number(row.lat),
      lng: number(row.lng),
      accuracy: row.locationAccuracy
    },
    gpx: {
      status: gpx.gpxStatus || "无轨迹",
      downloadable: bool(gpx.gpxDownloadable),
      file: gpx.gpxFile ? `.${gpx.gpxFile}` : "",
      homeFile: gpx.gpxFile || "",
      note: gpx.note || "暂无可下载轨迹。"
    }
  };
});

const activities = activityRows.map(row => ({
  id: row.id,
  title: row.title,
  club: row.club,
  date: row.date,
  routeId: row.routeId,
  region: row.region,
  difficulty: row.difficulty,
  distance: number(row.distance),
  ascent: number(row.ascent),
  meeting: row.meeting,
  transport: row.transport,
  fee: row.fee,
  status: row.status,
  tags: splitList(row.tags),
  signup: row.signup,
  signupUrl: row.signupUrl,
  audit: row.audit,
  note: row.note
}));

function routePage(route) {
  const gpxBlock = route.gpx.downloadable
    ? `<p>${route.gpx.note}</p><p><a class="download-link" href="${route.gpx.file}" download>下载测试 GPX</a></p>`
    : `<p>${route.gpx.note}</p>`;
  return pageShell(`${route.name}｜山迹`, `    <section class="detail-hero" style="--detail-color:${route.color}">
      <span class="status-chip">${route.id} · ${route.status}</span>
      <h1>${route.name}</h1>
      <p>${route.summary}</p>
    </section>
    <section class="detail-page-grid">
      <article class="detail-page-main">
        <h2>路线亮点</h2>
        <p>${route.highlight}</p>
        <h2>地图点位</h2>
        <p>当前点位：${route.location.lat}, ${route.location.lng}（${route.location.accuracy}）。V0.5 数据由 CSV 自动生成，正式发布前需要复核。</p>
        <p><a class="inline-link" href="${osmUrl(route)}" target="_blank" rel="noreferrer">在 OpenStreetMap 查看近似点位</a></p>
        <h2>风险提示</h2>
        <p>${route.warning}</p>
        <h2>发布前复核</h2>
        <p>${route.verify}</p>
        <h2>GPX轨迹</h2>
        ${gpxBlock}
      </article>
      <aside class="detail-page-side">
        <div class="detail-stat"><strong>${route.region}</strong><span>区域</span></div>
        <div class="detail-stat"><strong>${route.difficulty}</strong><span>难度</span></div>
        <div class="detail-stat"><strong>${route.distance}km</strong><span>距离</span></div>
        <div class="detail-stat"><strong>${route.time}h</strong><span>预计用时</span></div>
        <div class="detail-stat"><strong>${route.ascent}m</strong><span>累计爬升</span></div>
        <div class="detail-stat"><strong>${route.gpx.status}</strong><span>GPX状态</span></div>
      </aside>
    </section>`);
}

function activityPage(activity) {
  const linkedRoute = routes.find(route => route.id === activity.routeId);
  return pageShell(`${activity.title}｜山迹活动`, `    <section class="detail-hero" style="--detail-color:#7f9d68">
      <span class="status-chip">${activity.id} · ${activity.status}</span>
      <h1>${activity.title}</h1>
      <p>${activity.note}</p>
    </section>
    <section class="detail-page-grid">
      <article class="detail-page-main">
        <h2>活动摘要</h2>
        <p>${activity.date}，由${activity.club}发布。集合点：${activity.meeting}。交通方式：${activity.transport}。费用：${activity.fee}。</p>
        <h2>风险提示</h2>
        <p>${activity.note}</p>
        <h2>报名说明</h2>
        <p>山迹仅聚合活动信息，不代收费用。报名、保险、领队安排和行程变更以俱乐部官方说明为准。</p>
        <p>${activity.signupUrl ? `<a class="download-link" href="${activity.signupUrl}" target="_blank" rel="noreferrer">打开官方报名页</a>` : "暂无官方报名链接。"}</p>
        <h2>关联路线</h2>
        <p>${linkedRoute ? `<a class="inline-link" href="../routes/${linkedRoute.id}.html">${linkedRoute.name}</a>` : "该活动路线尚未进入路线库，可先作为活动信息展示。"}</p>
      </article>
      <aside class="detail-page-side">
        <div class="detail-stat"><strong>${activity.club}</strong><span>俱乐部</span></div>
        <div class="detail-stat"><strong>${activity.region}</strong><span>区域</span></div>
        <div class="detail-stat"><strong>${activity.difficulty}</strong><span>难度</span></div>
        <div class="detail-stat"><strong>${activity.distance}km</strong><span>距离</span></div>
        <div class="detail-stat"><strong>${activity.ascent}m</strong><span>累计爬升</span></div>
        <div class="detail-stat"><strong>${activity.audit}</strong><span>审核状态</span></div>
      </aside>
    </section>`);
}

await fs.writeFile(new URL("routes.js", dataDir), `window.SHANJI_ROUTES = ${JSON.stringify(routes, null, 2)};\n`);
await fs.writeFile(new URL("activities.js", dataDir), `window.SHANJI_CLUB_ACTIVITIES = ${JSON.stringify(activities, null, 2)};\n`);

await fs.mkdir(new URL("routes/", root), { recursive: true });
await fs.mkdir(new URL("activities/", root), { recursive: true });

for (const route of routes) {
  await fs.writeFile(new URL(`routes/${route.id}.html`, root), routePage(route));
}

for (const activity of activities) {
  await fs.writeFile(new URL(`activities/${activity.id}.html`, root), activityPage(activity));
}

const minLat = Math.min(...routes.map(route => route.location.lat)) - 0.05;
const maxLat = Math.max(...routes.map(route => route.location.lat)) + 0.05;
const minLng = Math.min(...routes.map(route => route.location.lng)) - 0.05;
const maxLng = Math.max(...routes.map(route => route.location.lng)) + 0.05;
const pins = routes.map(route => `
          <a class="coordinate-pin" href="./routes/${route.id}.html" style="left:${((route.location.lng - minLng) / (maxLng - minLng) * 100).toFixed(2)}%;top:${(100 - (route.location.lat - minLat) / (maxLat - minLat) * 100).toFixed(2)}%" title="${route.name}">${route.id.replace("FZ", "")}</a>`).join("");
const list = routes.map(route => `
        <a class="map-list-item" href="./routes/${route.id}.html">
          <strong>${route.name}</strong>
          <span>${route.region}｜${route.difficulty}｜${route.distance}km｜${route.location.accuracy}</span>
        </a>`).join("");

const mapPage = `<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>山迹路线地图｜V0.5</title>
  <link rel="stylesheet" href="./assets/styles.css?v=0.7">
</head>
<body>
  <main class="detail-page">
    <a class="back-link" href="./index.html">返回山迹首页</a>
    <section class="detail-hero" style="--detail-color:#5f9e78">
      <span class="status-chip">V0.5 地图页</span>
      <h1>路线地图</h1>
      <p>路线点位由 CSV 自动生成，当前仍为近似坐标，正式发布前需要复核。</p>
    </section>
    <section class="osm-panel">
      <iframe title="OpenStreetMap 福州周边视图" src="https://www.openstreetmap.org/export/embed.html?bbox=118.95%2C25.85%2C119.55%2C26.25&amp;layer=mapnik" loading="lazy"></iframe>
      <div class="coordinate-board" aria-label="路线近似点位图">
${pins}
      </div>
    </section>
    <section class="map-list">
${list}
    </section>
  </main>
</body>
</html>
`;

await fs.writeFile(new URL("map.html", root), mapPage);

const issues = [];
for (const route of routes) {
  for (const key of ["id", "name", "region", "difficulty", "highlight", "warning", "verify"]) {
    if (!route[key]) issues.push(`[路线 ${route.id}] 缺少 ${key}`);
  }
  if (!route.location.lat || !route.location.lng) issues.push(`[路线 ${route.id}] 缺少经纬度`);
  if (route.gpx.downloadable && !route.gpx.file) issues.push(`[路线 ${route.id}] 标记可下载但缺少GPX文件`);
}
for (const activity of activities) {
  for (const key of ["id", "title", "club", "date", "fee", "status", "note"]) {
    if (!activity[key]) issues.push(`[活动 ${activity.id}] 缺少 ${key}`);
  }
}

const report = `# 山迹 V0.5 数据检查报告

## 汇总

- 路线数量：${routes.length}
- 活动数量：${activities.length}
- 可下载 GPX：${routes.filter(route => route.gpx.downloadable).length}
- 问题数量：${issues.length}

## 问题

${issues.length ? issues.map(issue => `- ${issue}`).join("\n") : "未发现阻塞性数据问题。"}

## 说明

V0.5 已实现从 CSV 生成路线数据、活动数据、路线详情页、活动详情页和地图页。
`;

await fs.writeFile(new URL("data-check-v0.5.md", root), report);

const urls = [
  "index.html",
  "map.html",
  "about.html",
  "safety.html",
  "feedback.html",
  ...routes.map(route => `routes/${route.id}.html`),
  ...activities.map(activity => `activities/${activity.id}.html`)
];

const sitemap = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${urls.map(url => `  <url><loc>https://example.com/${url}</loc></url>`).join("\n")}
</urlset>
`;

await fs.writeFile(new URL("sitemap.xml", root), sitemap);
await fs.writeFile(new URL("robots.txt", root), `User-agent: *
Allow: /
Sitemap: https://example.com/sitemap.xml
`);
