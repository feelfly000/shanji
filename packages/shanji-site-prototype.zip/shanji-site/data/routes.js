window.SHANJI_ROUTES = [
      {
        id: "FZ001", name: "福道精华段", region: "鼓楼区", type: "城市森林步道", difficulty: "轻松",
        distance: 5.8, time: 2, ascent: 180, transit: "公交/打车", transitFriendly: true,
        themes: ["城市森林", "栈道", "亲子"], audience: ["新手", "亲子", "游客"], score: 98,
        highlight: "不用出城就能走的标志性城市森林步道，适合第一次体验。",
        summary: "适合用作网站的新手样板路线：路况清楚、出口较多、观景点密集，用户容易理解路线价值。",
        warning: "周末人流较大，雨天栈道可能湿滑，恐高人群需谨慎。",
        verify: "入口、开放时间、不同出口交通", x: "38%", y: "42%", color: "#7fb27a"
      },
      {
        id: "FZ002", name: "福山-福道-冶山历史风貌区", region: "鼓楼区", type: "城市山地+人文", difficulty: "轻松",
        distance: 6.2, time: 2.5, ascent: 160, transit: "公交/地铁周边", transitFriendly: true,
        themes: ["城市森林", "历史人文"], audience: ["新手", "游客", "摄影"], score: 89,
        highlight: "把福道和城市历史节点串起来，适合做文化轻徒步专题。",
        summary: "路线更偏城市漫步和轻量登高，适合外地游客或周末低强度活动。",
        warning: "需要确认实际串联动线，避免城市道路段过长影响体验。",
        verify: "实际步行串联方式和耗时", x: "39%", y: "39%", color: "#9dbf77"
      },
      {
        id: "FZ003", name: "鼓山登山道-涌泉寺", region: "晋安区", type: "古道登山", difficulty: "中等",
        distance: 7.5, time: 3.5, ascent: 520, transit: "地铁+步行/打车", transitFriendly: true,
        themes: ["古道", "寺庙", "城市观景"], audience: ["新手进阶", "半日", "摄影"], score: 96,
        highlight: "福州经典登高古道，交通方便，但台阶强度不低。",
        summary: "适合作为市区入门进阶路线。它的优势是识别度高、交通便利、文化景观密集。",
        warning: "雨后石阶湿滑，节假日人多，夏季闷热。",
        verify: "台阶强度、节假日人流、返程方式", x: "55%", y: "42%", color: "#6ea36f"
      },
      {
        id: "FZ004", name: "鼓山-十八景-喝水岩-白云顶", region: "晋安区", type: "古道+观景", difficulty: "较难",
        distance: 11.5, time: 5.5, ascent: 780, transit: "地铁+公交/打车", transitFriendly: true,
        themes: ["古道", "观景", "训练"], audience: ["进阶", "摄影"], score: 91,
        highlight: "比普通鼓山线更完整，适合有一定体力的人做半日到一日训练。",
        summary: "这条线可以展示路线详情页的分段说明、风险提示和下撤信息，是原型里的进阶样板。",
        warning: "爬升明显，部分路段需确认开放和路况，不建议新手独行。",
        verify: "分段距离、爬升、白云顶开放状态", x: "58%", y: "36%", color: "#8b7749"
      },
      {
        id: "FZ005", name: "鼓山白云洞/凤池白云洞线", region: "晋安区", type: "登山观景", difficulty: "较难",
        distance: 9.2, time: 4.5, ascent: 720, transit: "公交/打车", transitFriendly: false,
        themes: ["观景", "寺庙", "训练"], audience: ["进阶", "摄影"], score: 80,
        highlight: "观景和登山属性强，适合做进阶路线内容。",
        summary: "路线需要更严格核验，适合展示网站对高强度路线的安全边界表达。",
        warning: "台阶多、体力要求较高，雨后和夜间不建议尝试。",
        verify: "台阶数量、路况、是否适合下山", x: "57%", y: "34%", color: "#8d5f45"
      },
      {
        id: "FZ006", name: "鼓山-鼓岭线路", region: "晋安区", type: "古道+避暑", difficulty: "较难",
        distance: 13.5, time: 6, ascent: 900, transit: "公交/接驳", transitFriendly: false,
        themes: ["古道", "避暑", "历史人文"], audience: ["进阶", "游客"], score: 88,
        highlight: "官方十大名山线路之一，兼具古道、人文和夏季避暑价值。",
        summary: "适合做鼓山鼓岭专题的核心路线，但正式发布前要细化起终点和交通。",
        warning: "耗时较长，返程接驳需要提前计划。",
        verify: "具体起终点、接驳交通、耗时", x: "60%", y: "31%", color: "#4d8b6f"
      },
      {
        id: "FZ007", name: "鼓岭柳杉王公园-鼓岭栈道", region: "晋安区", type: "避暑轻徒步", difficulty: "轻松",
        distance: 5.6, time: 2.2, ascent: 180, transit: "公交/自驾", transitFriendly: true,
        themes: ["森林", "避暑", "亲子"], audience: ["新手", "亲子", "游客"], score: 92,
        highlight: "夏季避暑、亲子和游客都容易理解的轻徒步选择。",
        summary: "适合作为夏季专题入口，强度不高但交通和停车信息要写清楚。",
        warning: "山上天气变化快，节假日停车和接驳需提前确认。",
        verify: "景区交通、开放时间、停车", x: "62%", y: "28%", color: "#5f9e78"
      },
      {
        id: "FZ008", name: "五虎山-五灵岩寺折返", region: "闽侯县", type: "郊野登山", difficulty: "中等",
        distance: 8.4, time: 4, ascent: 560, transit: "自驾/打车", transitFriendly: false,
        themes: ["名山", "寺庙", "训练"], audience: ["新手进阶", "进阶"], score: 84,
        highlight: "山体辨识度高，适合作为闽侯方向的登山样板。",
        summary: "适合有一定体力的周末登山用户，正式发布时要确认停车和折返点。",
        warning: "部分路段暴晒，雨后土路和石阶需注意防滑。",
        verify: "起点停车、步道状态、折返节点", x: "30%", y: "66%", color: "#94734c"
      },
      {
        id: "FZ009", name: "五虎山-龙祥岛-旗山湖", region: "闽侯县", type: "山岛湖串联", difficulty: "中等",
        distance: 12, time: 5.5, ascent: 480, transit: "自驾/接驳", transitFriendly: false,
        themes: ["名山", "湖景", "亲水"], audience: ["进阶", "游客"], score: 78,
        highlight: "官方十大名山线路之一，适合做闽侯山岛湖专题。",
        summary: "更像目的地串联路线，网站里需要区分徒步段和游览段。",
        warning: "点位串联可能依赖车辆接驳，不应直接宣传为纯徒步线。",
        verify: "串联是否适合步行、交通接驳", x: "28%", y: "70%", color: "#608ba4"
      },
      {
        id: "FZ010", name: "旗山-万佛寺-博思软件线路", region: "闽侯县/高新区", type: "名山+古刹", difficulty: "中等",
        distance: 10.8, time: 5, ascent: 620, transit: "自驾/公交部分可达", transitFriendly: false,
        themes: ["名山", "寺庙", "森林"], audience: ["新手进阶", "进阶"], score: 82,
        highlight: "名山、古刹和产业园区形成多元路线主题。",
        summary: "适合在原型里测试复杂路线的标签和专题归类。",
        warning: "需要确认实际徒步段比例，避免城市道路段过多。",
        verify: "实际徒步段和城市道路占比", x: "24%", y: "58%", color: "#7f9d68"
      },
      {
        id: "FZ011", name: "旗山森林公园轻徒步", region: "闽侯县", type: "森林/溪谷", difficulty: "轻松",
        distance: 6, time: 2.5, ascent: 260, transit: "自驾/打车", transitFriendly: false,
        themes: ["森林", "溪谷", "避暑"], audience: ["新手", "亲子", "避暑"], score: 86,
        highlight: "森林感强、坡度相对温和，适合周末半日放松。",
        summary: "适合新手和亲子，但需要确认景区状态和溪谷安全边界。",
        warning: "雨后溪边湿滑，部分谷地信号可能较弱。",
        verify: "景区开放状态、门票、溪谷风险", x: "22%", y: "56%", color: "#609b73"
      },
      {
        id: "FZ012", name: "飞凤山-海峡奥体中心", region: "仓山区", type: "城市山地", difficulty: "轻松",
        distance: 5.4, time: 2, ascent: 180, transit: "公交/地铁周边", transitFriendly: true,
        themes: ["城市观景", "公园", "半日"], audience: ["新手", "亲子", "夜走谨慎"], score: 83,
        highlight: "市区南部轻徒步代表，适合半日线和下班后短走。",
        summary: "路线适合验证移动端用户按附近区域找路线的需求。",
        warning: "夜间路线需确认照明和人流，不建议走偏僻支路。",
        verify: "可走步道入口、停车、夜间安全", x: "43%", y: "59%", color: "#81a76b"
      },
      {
        id: "FZ013", name: "高盖山生态公园线", region: "仓山区", type: "城市登山", difficulty: "轻松",
        distance: 5.2, time: 2, ascent: 210, transit: "公交/打车", transitFriendly: true,
        themes: ["城市观景", "公园", "亲子"], audience: ["新手", "亲子", "半日"], score: 87,
        highlight: "南台岛中心山体，适合仓山周边用户快速出门走山。",
        summary: "适合做城市轻徒步专题，也是亲子和新手筛选里的好样例。",
        warning: "入口较多，正式内容需给出最清楚的推荐走法。",
        verify: "入口选择、步道完整度、夜间照明", x: "41%", y: "63%", color: "#789e62"
      },
      {
        id: "FZ014", name: "天马山-中国船政文化景区", region: "马尾区", type: "登山+人文", difficulty: "中等",
        distance: 7.8, time: 3.5, ascent: 360, transit: "公交/自驾", transitFriendly: true,
        themes: ["城市观景", "历史人文", "江景"], audience: ["游客", "摄影", "新手进阶"], score: 81,
        highlight: "登山观景和船政文化结合，适合做马尾人文路线。",
        summary: "路线价值在于山体和文化景区的组合，详情页要写清楚两者如何衔接。",
        warning: "城市道路和景区段占比需核实，夏季注意暴晒。",
        verify: "山路与景区串联方式", x: "68%", y: "49%", color: "#7f8fa1"
      },
      {
        id: "FZ015", name: "石竹山-东关寨-罗汉里", region: "福清市", type: "山地+古堡+红色文化", difficulty: "中等",
        distance: 14.5, time: 6.5, ascent: 650, transit: "自驾/接驳", transitFriendly: false,
        themes: ["名山", "古村", "历史人文"], audience: ["进阶", "游客"], score: 76,
        highlight: "梦文化、古堡和红色记忆层次丰富，适合做深度专题。",
        summary: "更适合做一日游路线，需要谨慎区分徒步段与车辆串联段。",
        warning: "点位距离较远，直接步行串联可能不适合普通用户。",
        verify: "点位距离较远，需确认是否适合徒步串联", x: "45%", y: "86%", color: "#956a4c"
      },
      {
        id: "FZ016", name: "青芝山-贵安旅游度假区", region: "连江县", type: "山地+景区", difficulty: "中等",
        distance: 9.5, time: 4.5, ascent: 520, transit: "自驾/公交部分可达", transitFriendly: false,
        themes: ["山水", "洞泉", "景区"], audience: ["新手进阶", "游客"], score: 79,
        highlight: "山、溪、湖、滩、谷资源丰富，适合景区型徒步内容。",
        summary: "适合连江方向内容建设，但景区收费和串联方式必须写清楚。",
        warning: "节假日景区人流和停车可能影响体验。",
        verify: "串联交通、景区开放和收费", x: "70%", y: "24%", color: "#5c9476"
      },
      {
        id: "FZ017", name: "汤岭古道贵安-降虎寨", region: "连江县/贵安周边", type: "古道", difficulty: "中等",
        distance: 9, time: 4, ascent: 460, transit: "自驾/接驳", transitFriendly: false,
        themes: ["古道", "森林", "村寨"], audience: ["新手进阶", "摄影"], score: 85,
        highlight: "古道特色鲜明，适合做福州周边古道专题。",
        summary: "路线具备故事性和风景辨识度，发布前应优先确认起终点和岔路。",
        warning: "古道可能存在杂草、岔路和雨后湿滑问题。",
        verify: "起终点定位、全程路况、岔路", x: "72%", y: "22%", color: "#717d51"
      },
      {
        id: "FZ018", name: "连江奇达村-旗冠顶", region: "连江县", type: "山海观景", difficulty: "中等",
        distance: 6.8, time: 3, ascent: 430, transit: "自驾/包车", transitFriendly: false,
        themes: ["看海", "山海", "摄影"], audience: ["摄影", "游客", "新手进阶"], score: 93,
        highlight: "山海景观强，适合作为网站最容易传播的看海路线。",
        summary: "视觉吸引力强，适合首页推荐和看海专题，但安全护栏与人流需核实。",
        warning: "台阶强度不低，临海观景注意安全，节假日人流较大。",
        verify: "台阶强度、停车、人流、安全护栏", x: "83%", y: "31%", color: "#2f8aa2"
      },
      {
        id: "FZ019", name: "长乐西洛岛灯塔线", region: "长乐区", type: "海岛/海岸", difficulty: "轻松",
        distance: 6.5, time: 3, ascent: 120, transit: "自驾/包车", transitFriendly: false,
        themes: ["看海", "灯塔", "日出"], audience: ["摄影", "情侣", "轻徒步"], score: 90,
        highlight: "看海、灯塔和日出主题鲜明，适合社交传播。",
        summary: "适合看海专题和摄影专题，但必须强调潮汐、风浪和天气。",
        warning: "海岸线受潮汐和风浪影响，台风天和恶劣天气不要前往。",
        verify: "潮汐、风浪、上岛路径安全", x: "76%", y: "66%", color: "#3d99b2"
      },
      {
        id: "FZ020", name: "永泰天门山-赤壁-欧乐堡周边线", region: "永泰县", type: "山地/景区串联", difficulty: "较难",
        distance: 15.8, time: 7, ascent: 850, transit: "自驾/接驳", transitFriendly: false,
        themes: ["山地", "溪谷", "景区"], audience: ["进阶", "避暑"], score: 75,
        highlight: "永泰方向代表性山地景区串联，适合做进阶和避暑专题。",
        summary: "这类路线更适合一日或两日安排，网站需要明确交通和门票边界。",
        warning: "景区间距离和纯徒步可行性需核实，不建议直接按一条徒步线发布。",
        verify: "景区间距离、是否适合纯徒步、门票", x: "20%", y: "82%", color: "#6d7f62"
      }
    ];
