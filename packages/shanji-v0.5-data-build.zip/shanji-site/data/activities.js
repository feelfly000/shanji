window.SHANJI_CLUB_ACTIVITIES = [
  {
    "id": "A202607001",
    "title": "周五鼓山夜爬轻徒步",
    "club": "示例户外A",
    "date": "周五晚",
    "routeId": "FZ003",
    "region": "晋安区",
    "difficulty": "中等",
    "distance": 7,
    "ascent": 520,
    "meeting": "鼓山地铁站",
    "transport": "公共交通集合",
    "fee": "39元",
    "status": "报名中",
    "tags": [
      "新手进阶",
      "夜爬",
      "市区"
    ],
    "signup": "俱乐部官方报名页",
    "audit": "已审核",
    "note": "适合有基础的新手，雨后取消或改线。"
  },
  {
    "id": "A202607002",
    "title": "周六奇达旗冠顶看海线",
    "club": "示例户外B",
    "date": "周六",
    "routeId": "FZ018",
    "region": "连江县",
    "difficulty": "中等",
    "distance": 6.8,
    "ascent": 430,
    "meeting": "五一广场附近",
    "transport": "大巴往返",
    "fee": "128元",
    "status": "余位紧张",
    "tags": [
      "看海",
      "摄影",
      "山海"
    ],
    "signup": "俱乐部官方报名页",
    "audit": "已审核",
    "note": "临海观景注意安全，台阶强度不低，需自备午餐。"
  },
  {
    "id": "A202607003",
    "title": "周六福道亲子轻徒步",
    "club": "示例亲子户外",
    "date": "周六上午",
    "routeId": "FZ001",
    "region": "鼓楼区",
    "difficulty": "轻松",
    "distance": 5.8,
    "ascent": 180,
    "meeting": "福道入口",
    "transport": "自行前往",
    "fee": "免费/AA",
    "status": "报名中",
    "tags": [
      "亲子",
      "新手",
      "城市森林"
    ],
    "signup": "俱乐部官方报名页",
    "audit": "待审核",
    "note": "适合亲子轻量体验，需确认集合点和儿童年龄建议。"
  },
  {
    "id": "A202607004",
    "title": "周日永泰溪谷避暑线",
    "club": "示例户外C",
    "date": "周日",
    "routeId": "FZ020",
    "region": "永泰县",
    "difficulty": "较难",
    "distance": 12,
    "ascent": 650,
    "meeting": "市区指定集合点",
    "transport": "大巴往返",
    "fee": "158元",
    "status": "待确认",
    "tags": [
      "进阶",
      "避暑",
      "溪谷"
    ],
    "signup": "俱乐部官方报名页",
    "audit": "待审核",
    "note": "雨天自动取消或改线，需确认溪谷涨水风险。"
  },
  {
    "id": "A202607005",
    "title": "周日鼓岭避暑半日线",
    "club": "示例户外D",
    "date": "周日",
    "routeId": "FZ007",
    "region": "晋安区",
    "difficulty": "轻松",
    "distance": 5.6,
    "ascent": 180,
    "meeting": "鼓岭柳杉王公园",
    "transport": "自驾/拼车",
    "fee": "68元",
    "status": "报名中",
    "tags": [
      "新手",
      "亲子",
      "避暑"
    ],
    "signup": "俱乐部官方报名页",
    "audit": "已审核",
    "note": "山上天气变化快，建议带薄外套和饮水。"
  }
];
